import textwrap
import uuid
from treelib import Tree
import treelib
import graphviz

import pgsn.dsl
import pgsn.pgsn_term

# Every GSN node carries `defeaters`: the dialectic extension of GSN v3 lets a
# defeater challenge a goal, a strategy or a solution, and a defeater is itself
# a GSN node, so it can be challenged in turn.
gsn_class = pgsn.dsl.define_class(inherit=pgsn.dsl.base_class,
                                     name='GSN_Node',
                                     attributes=["description", "defeaters"],
                                     defaults={"defeaters": []})

support_class = pgsn.dsl.define_class(inherit=gsn_class, name='Support')
undeveloped_class = pgsn.dsl.define_class(inherit=support_class,
                                          name='Undeveloped',
                                          defaults={"description": ""})
undeveloped = undeveloped_class()
evidence_class = pgsn.dsl.define_class(inherit=support_class, name='Evidence')
# A Context or an Assumption attaches to a Goal or a Strategy, which is what
# lets a strategy carry the assumption its reasoning depends on -- GSN
# Community Standard Figure 6 does exactly that with "All hazards have been
# identified". Evidence takes neither: the standard attaches nothing to a
# Solution.
strategy_class = pgsn.dsl.define_class(inherit=support_class, name='Strategy',
                                          attributes=["assumptions",
                                                      "contexts",
                                                      "sub_goals"],
                                          defaults={"assumptions": [],
                                                    "contexts": []})

goal_class = pgsn.dsl.define_class(inherit=gsn_class,
                                      name='Goal',
                                      attributes=["assumptions", "contexts", "support"],
                                      defaults={"assumptions":[], "contexts": [], "support": undeveloped}
                                      )
# Context and Assumption are documentation nodes. In GSN each carries a
# statement and nothing else, so `description` is the only field they need.
assumption_class = pgsn.dsl.define_class(inherit=gsn_class, name='Assumption')
context_class = pgsn.dsl.define_class(inherit=gsn_class, name='Context')

# Dialectic extension (GSN v3). A defeater challenges the node that holds it.
#
# The standard has no Defeater element: a defeater is an ordinary Goal or
# Solution linked to its target by a Challenges relationship, and the
# rebutting/undercutting distinction is read off the argument rather than the
# notation. PGSN makes the challenging role a class instead, because a term
# language has no edges to carry the relationship. One class is enough; a
# defeater that argues its case fills in `support`, and one that merely states
# an objection leaves it undeveloped.
defeater_class = pgsn.dsl.define_class(inherit=gsn_class, name='Defeater',
                                       attributes=["support"],
                                       defaults={"support": undeveloped})

_d = pgsn.dsl.variable('x')
_support = pgsn.dsl.variable('support')
_assumptions = pgsn.dsl.variable('assumptions')
_contexts = pgsn.dsl.variable('contexts')
_sub_goals = pgsn.dsl.variable('sub_goals')
_defeaters = pgsn.dsl.variable('defeaters')

evidence = pgsn.dsl.lambda_abs_keywords(
    arguments={'description': _d, 'defeaters': _defeaters},
    defaults=pgsn.dsl.record({'defeaters': pgsn.dsl.empty}),
    body=evidence_class(description=_d, defeaters=_defeaters))
strategy = pgsn.dsl.lambda_abs_keywords(
    arguments={'description': _d, 'sub_goals': _sub_goals,
               'assumptions': _assumptions, 'contexts': _contexts,
               'defeaters': _defeaters},
    defaults=pgsn.dsl.record({'assumptions': pgsn.dsl.empty,
                              'contexts': pgsn.dsl.empty,
                              'defeaters': pgsn.dsl.empty}),
    # The attributes are written in the order a renderer reports them in, now
    # that nothing sorts them: what a node is said in the context of, then what
    # challenges it, then what it rests on. A Goal is built the same way.
    body=strategy_class(description=_d, contexts=_contexts,
                        assumptions=_assumptions, defeaters=_defeaters,
                        sub_goals=_sub_goals))
goal = pgsn.dsl.lambda_abs_keywords(arguments={'description': _d,
                                      'assumptions': _assumptions,
                                      'contexts': _contexts,
                                      'defeaters': _defeaters,
                                      'support': _support},
                                       defaults=pgsn.dsl.record({
                               'assumptions': pgsn.dsl.empty,
                               'contexts': pgsn.dsl.empty,
                               'defeaters': pgsn.dsl.empty}),
                                       body=goal_class(description=_d,
                                                       contexts=_contexts,
                                                       assumptions=_assumptions,
                                                       defeaters=_defeaters,
                                                       support=_support))
assumption = pgsn.dsl.lambda_abs_keywords(
    arguments={'description': _d},
    body=assumption_class(description=_d))
context = pgsn.dsl.lambda_abs_keywords(
    arguments={'description': _d},
    body=context_class(description=_d))

defeater = pgsn.dsl.lambda_abs_keywords(
    arguments={'description': _d, 'support': _support,
               'defeaters': _defeaters},
    defaults=pgsn.dsl.record({'support': undeveloped,
                              'defeaters': pgsn.dsl.empty}),
    body=defeater_class(description=_d, support=_support,
                        defeaters=_defeaters))

_goals = pgsn.dsl.variable('goals')
immediate = pgsn.dsl.lambda_abs(_goals, strategy(description="immediate", sub_goals=_goals))

_evd = pgsn.dsl.variable('evidence')
evidence_as_goal = pgsn.dsl.lambda_abs(_evd, goal(description=_evd('description'), support=_evd))

# Keys for lists whose children should be attached directly to the parent.
# An empty list therefore contributes nothing, which is what keeps a node
# without contexts, assumptions or defeaters from showing empty entries.
GSN_KEYS_TO_FLATTEN = {"support", "sub_goals", "contexts", "assumptions",
                       "defeaters"}
GSN_TYPES = {"Goal", "Strategy", "Evidence", "Context", "Assumption",
             "Undeveloped", "Defeater"}

# The kinds of node that challenge rather than support what holds them.
GSN_DEFEATER_TYPES = {"Defeater"}


# Term and to_python are assumed to be in your module
# from your_module import Term, to_python


import uuid

# Tree と pgsn は君のモジュールでインポートされている前提だね

def gsn_tree(root_term: pgsn.pgsn_term.Term) -> Tree:
    tree = Tree()
    # 継承チェーンを含めてPythonの辞書に変換
    py_data = pgsn.dsl.python_value(root_term, with_inherit_chain=True)

    def _add_nodes(data, parent_id=None, key_name="root"):
        node_id = str(uuid.uuid4())

        if isinstance(data, dict):
            # 血脈（親クラスのリスト）を取り出す
            parent_classes = data.get("__parent_classes__", [])

            # その血脈の中に、GSN_TYPES に該当する起源があるかを探す
            gsn_type = next((cls for cls in parent_classes if cls in GSN_TYPES), None)

            # 実際のクラス名（派生クラス名。GSN以外のオブジェクト表示用として残す）
            class_name_key = next(
                (k for k in data if k.startswith('__') and k.endswith('__') and k != '__parent_classes__'), None)
            class_name = class_name_key.strip('_') if class_name_key is not None else None

            has_meaningful_keys = any(not (k.startswith('__') and k.endswith('__')) for k in data)

            # --- ノードのタグ（表示名）の決定 ---
            if gsn_type:
                description = data.get("description", "")
                # 【変更点】class_name（派生クラス）ではなく、gsn_type（祖先クラス）を表示する
                node_tag = f"{gsn_type}: {description}"
            elif class_name_key:
                # GSNの血脈は持たない純粋なPGSNObjectの場合
                node_tag = f"{key_name}: <{class_name}>"
            elif not has_meaningful_keys:
                node_tag = f"{key_name}: {{}}"
            else:
                node_tag = f"{key_name}: <Record>"

            tree.create_node(tag=node_tag, identifier=node_id, parent=parent_id)

            for key, value in data.items():
                if key.startswith('__') and key.endswith('__'):
                    continue

                if gsn_type and key == "description":
                    continue

                if key in GSN_KEYS_TO_FLATTEN and isinstance(value, list):
                    for item in value:
                        _add_nodes(item, parent_id=node_id, key_name=key)
                else:
                    _add_nodes(value, parent_id=node_id, key_name=key)

        elif isinstance(data, list):
            if not data:
                node_tag = f"{key_name}: [List] =[]"
            else:
                node_tag = f"{key_name}: [List]"

            tree.create_node(tag=node_tag, identifier=node_id, parent=parent_id)

            for i, item in enumerate(data):
                _add_nodes(item, parent_id=node_id, key_name=f"[{i}]")

        else:
            node_tag = f"{key_name}: {data}"
            tree.create_node(tag=node_tag, identifier=node_id, parent=parent_id)

    _add_nodes(py_data)
    return tree


GSN_SHAPES = {
        'Goal': 'box',
        'Strategy': 'polygon',
        'Evidence': 'ellipse',  # Evidenceは円で表現することが多い
        'Solution': 'ellipse',  # Solutionも円で
        'Context': 'box',  # 本来は角丸だけど、まずは四角で
        'Assumption': 'ellipse',
        'Undeveloped': 'diamond',
        # The dialectic extension draws every defeater with one glyph.
        'Defeater': 'hexagon',
    }


# Graphviz sets a label on one line unless the label says otherwise, so a node
# is as wide as the longest sentence in it. A generated case states a whole
# provision in a description, which is how a drawing ends up several times
# wider than it is tall.
LABEL_WIDTH = 40


def _wrap(label: str, width: int) -> str:
    """Wrap each line of a label to `width` columns; 0 leaves it alone.

    The lines are wrapped one at a time because the breaks already there carry
    meaning: the type heading, the description, and the attributes folded into
    the box are separate things.
    """
    if width <= 0:
        return label
    lines = []
    for line in label.split("\n"):
        lines.extend(textwrap.wrap(line, width) or [""])
    return "\n".join(lines)


def gsn_dot(gsn: pgsn.pgsn_term.Term,
            layout_attrs: dict[str, str] | None = None,
            label_width: int = LABEL_WIDTH) -> graphviz.Digraph:
    """
    treelib.Treeオブジェクトを受け取り、GSNのルールに基づいて
    ノードの形をカスタマイズしたdotファイルを生成する。
    """
    tree = gsn_tree(gsn)

    default_layout = {
        "rankdir": "TB",
        # Straight lines are drawn through whatever stands between two nodes;
        # splines are routed around it.
        "splines": "spline",
        "nodesep": "0.6",
        "ranksep": "1.2"
    }
    if layout_attrs:
        default_layout.update(layout_attrs)

    dot = graphviz.Digraph('GSN', comment='Goal Structuring Notation')
    dot.attr(**default_layout)

    horizontal_pairs = []
    skipped_nodes = set()  # 親の箱に吸収された属性ノードのIDを記録

    # treelib sorts siblings by tag unless told otherwise, which would draw the
    # children of a node in alphabetical rather than document order. The order
    # of a List is part of what a document says, so it is kept here as well:
    # the sequence the nodes are emitted in is what graphviz lays them out by.
    for node in tree.expand_tree(mode=treelib.Tree.DEPTH, sorting=False):
        # すでに親の箱に吸収されたノードは、独立した箱として描かない
        if node in skipped_nodes:
            continue

        node_obj = tree.get_node(node)
        tag = node_obj.tag

        node_type = None  # 'Default'という仮の名前は捨てる
        node_label = tag

        if ': ' in tag:
            parts = tag.split(': ', 1)
            # parts[0]がGSN_TYPESに含まれているかチェック
            if parts[0] in GSN_TYPES:
                node_type = parts[0]
                node_label = parts[1]

        # A defeater that carries no support is an objection put without
        # grounds, and the absence of anything beneath it says so. Drawing the
        # marker as well puts a diamond under every challenging defeater a
        # generator emits, which crowds out the undeveloped goals -- the ones a
        # reader is looking for. A goal keeps its marker.
        if node_type == 'Undeveloped' and node_obj.is_leaf() and not node_obj.is_root():
            parent_tag = tree.get_node(node_obj.predecessor(tree.identifier)).tag
            if parent_tag.split(': ', 1)[0] in GSN_DEFEATER_TYPES:
                continue

        # --- 子ノードを覗き込んで、単なる属性なら親の箱の中に吸収する ---
        children = tree.children(node)
        attr_lines = []
        for child in children:
            child_tag = child.tag
            child_parts = child_tag.split(': ', 1)
            is_gsn = len(child_parts) > 1 and child_parts[0] in GSN_TYPES

            # GSNノードではなく、かつ子を持たない「葉っぱ」のノード（数値やBooleanも含む）の場合
            if not is_gsn and child.is_leaf():
                attr_lines.append(child_tag)
                skipped_nodes.add(child.identifier)

        # 吸収した属性があれば、ラベルの文字列に改行(\n)で合体させる
        if attr_lines:
            node_label += "\n" + "\n".join(attr_lines)
        # -------------------------------------------------------------------------

        # GSNタイプに基づいて形を決定する（GSN以外は単なる四角形）
        shape = GSN_SHAPES.get(node_type, 'box') if node_type else 'box'
        style = ''
        node_attrs = {}

        if node_type in GSN_DEFEATER_TYPES:
            # A defeater challenges rather than supports, so it is drawn with a
            # broken outline to keep it from reading as part of the argument.
            style = 'dashed'
        elif node_type == 'Context':
            style = 'rounded'
        elif node_type == 'Strategy':
            node_attrs['sides'] = '4'
            node_attrs['skew'] = '0.3'
            node_attrs['margin'] = '0'

        # ラベルの最終決定（GSNならタイプ名を見出しにし、それ以外はタグをそのまま使う）
        final_label = f"{node_type}\n{node_label}" if node_type else node_label

        dot.node(
            name=node_obj.identifier,
            label=_wrap(final_label, label_width),
            shape=shape,
            style=style,
            **node_attrs
        )

        edge_attrs = {}
        if not node_obj.is_root():
            parent_id = node_obj.predecessor(tree.identifier)
            parent_node_obj = tree.get_node(parent_id)
            parent_tag_parts = parent_node_obj.tag.split(': ', 1)
            parent_node_type = parent_tag_parts[0] if len(parent_tag_parts) > 1 else 'Default'

            if node_type in ('Assumption', 'Context'):
                edge_attrs['dir'] = 'back'
                horizontal_pairs.append((parent_id, node_obj.identifier))

            if node_type in GSN_DEFEATER_TYPES:
                # Challenges point at what they attack, and are dashed so the
                # relation is not mistaken for SupportedBy.
                #
                # Unlike a Context or an Assumption, a defeater is not an
                # annotation placed beside its target: it is an argument in its
                # own right, with a support and defeaters of its own beneath
                # it. Pinning it to its target's rank leaves it nowhere to grow
                # but sideways, and a node with many defeaters then spreads its
                # rank across the whole drawing.
                edge_attrs['dir'] = 'back'
                edge_attrs['style'] = 'dashed'

            if parent_node_type == 'Goal' and node_type == 'Evidence':
                edge_attrs['tailport'] = 's'
                edge_attrs['headport'] = 'n'
                edge_attrs['weight'] = '10'

            dot.edge(parent_id, node_obj.identifier, **edge_attrs)

    # まとめて水平配置の魔法をかける
    for parent, child in horizontal_pairs:
        dot.body.append(f'{{ rank=same; "{parent}"; "{child}" }}')

    return dot

def save_gsn(gsn: pgsn.pgsn_term.Term,
             filename: str,
             image_format: str = "png",
             view=False,
             cleanup=True,
             label_width: int = LABEL_WIDTH):

    dot = gsn_dot(gsn, label_width=label_width)
    dot.render(filename, view=view, format=image_format, cleanup=cleanup)