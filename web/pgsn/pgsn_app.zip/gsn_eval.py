"""
エディタから届いた図を評価して、エディタ用のJSONにして返す。

エディタはブラウザ内のPython（Pyodide）でこのファイルを動かす（評価サーバは使わない）。
ブラウザ用の一式は tools/build_pyodide_bundle.py で作る。
"""
import json
import os
import tempfile

from build_gsn import build_gsn_from_json, export_gsn_json
from pgsn.pgsn_term import LambdaInterpreterError


class InvalidRequest(ValueError):
    """リクエストの形式が正しくない"""


def evaluate_request(gsn_data: dict) -> dict:
    """図（nodes/edges と任意の csv_files）を評価し、最初のトップゴールの結果を返す。

    評価できなかったときは、元の図（csv_files を除く）をそのまま返す。
    """
    # エディタがアカウント（Firestore）に保存したCSVの中身（ファイル名 → 中身）。
    # 図とは別に受け取り、一時ファイルにも、エラー時に返す元の図にも含めない。
    csv_files = gsn_data.pop("csv_files", None) or {}
    if not isinstance(csv_files, dict) or not all(
            isinstance(k, str) and isinstance(v, str) for k, v in csv_files.items()):
        raise InvalidRequest("csv_files の形式が正しくありません")

    # build_gsn_from_json はファイルを読むので、一時ファイルに書き出す
    fd, temp_path = tempfile.mkstemp(prefix="gsn_", suffix=".json")
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(gsn_data, f, ensure_ascii=False, indent=2)

        try:
            # 1. PGSNのノード構築
            tops, _node_objs = build_gsn_from_json(temp_path, csv_files=csv_files)
        except Exception as e:
            # ノード構築自体が失敗した場合も元の入力図を返す
            print(f"BUILD ERROR: {e}")
            return gsn_data
    finally:
        os.remove(temp_path)

    if not tops:
        return {"nodes": [], "edges": []}

    top = tops[0]
    try:
        # 2. PGSNの評価実行（Termオブジェクトが返る）
        evaluated_term = top.fully_eval()
        # 3. TermをFlutter用のフラットなJSON形式に変換
        return export_gsn_json(evaluated_term)

    except LambdaInterpreterError as e:
        # ステップ超過: e.args[1]に途中まで評価されたTermが入っている
        partial_term = e.args[1]
        print(f"EVAL INCOMPLETE (step limit): 途中のTermで出力します")
        return export_gsn_json(partial_term, safe=True)

    except Exception as eval_error:
        # その他のエラー: 元の入力図をそのまま返す
        print(f"EVAL ERROR: {eval_error}")
        return gsn_data


def evaluate_json(request_json: str) -> str:
    """ブラウザ（Pyodide）から呼ぶ入口。JSON文字列を受け取り、JSON文字列を返す。

    形式の誤りは {"error": ...} で返す。
    """
    try:
        gsn_data = json.loads(request_json)
        if not gsn_data:
            raise InvalidRequest("データがありません")
        result = evaluate_request(gsn_data)
    except (InvalidRequest, json.JSONDecodeError) as e:
        result = {"error": str(e)}
    return json.dumps(result, ensure_ascii=False)
