"""
FlutterのGSNエディタとPGSNを繋ぐ変換レイヤー（エディタのブラウザ内でPyodideにより動く）。

処理フロー:
  1. build_gsn_from_json() : FlutterのノードJSON（nodes/edges形式）→ PGSNオブジェクトツリー
  2. fully_eval()          : PGSNエンジンによるラムダ式の評価（pgsn パッケージ側）
  3. export_gsn_json()     : 評価済みTerms → Flutter描画用フラットJSON（nodes/edges形式）
"""
import csv
import io
import json
import math
import os
import traceback
from typing import Dict, List, Optional, Tuple, Any
import sys

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")


def _open_csv(filename: str, csv_files: Optional[Dict[str, str]]) -> io.StringIO:
    """
    CSVの中身をテキストとして開く。
    エディタはアカウント（Firestore）に保存したCSVの中身を評価リクエストの csv_files
    （ファイル名 → 中身）で一緒に送ってくるので、あればそれを使う。
    無ければ従来どおり data/ フォルダから読む（古いエディタやCLI実行のため）。
    """
    if csv_files and filename in csv_files:
        # 先頭のBOMは data/ からの読み込み(utf-8-sig)と同じく取り除く
        return io.StringIO(csv_files[filename].lstrip("\ufeff"), newline="")

    filepath = os.path.join(DATA_DIR, os.path.basename(filename))
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"CSVファイルが見つかりません: {filename}")
    with open(filepath, encoding="utf-8-sig", newline="") as f:
        return io.StringIO(f.read(), newline="")


def load_csv_as_list_term(filename: str, csv_files: Optional[Dict[str, str]] = None):
    """
    CSVを読み込み、PGSNのlist_termに変換する（読み込み元は _open_csv() を参照）。
    - 1列CSVならStringLiteralのリスト
    - 複数列CSVならRecordのリスト（1行目をヘッダーとして使う）
    """
    with _open_csv(filename, csv_files) as f:
        reader = csv.reader(f)
        rows = [row for row in reader if any(cell.strip() for cell in row)]

    if not rows:
        return list_term(())

    if len(rows[0]) == 1:
        # 1列: 全行をStringLiteralとして扱う
        terms = tuple(string(row[0].strip()) for row in rows)
    else:
        # 複数列: 1行目をヘッダー、2行目以降をRecordとして扱う
        headers = [h.strip() for h in rows[0]]
        terms = tuple(
            record({headers[i]: string(cell.strip()) for i, cell in enumerate(row) if i < len(headers)})
            for row in rows[1:]
        )

    return list_term(terms)


def load_csv_as_record(filename: str, csv_files: Optional[Dict[str, str]] = None):
    """
    複数列CSVを読み込み、PGSNのrecordに変換する（読み込み元は _open_csv() を参照）。
    1行目をキー（ヘッダー）、2行目を値として1つのRecordを返す。
    """
    with _open_csv(filename, csv_files) as f:
        reader = csv.DictReader(f)
        row = next(reader, None)

    if row is None:
        raise ValueError(f"CSVにデータ行がありません: {filename}")

    return record({k.strip(): string(v.strip()) for k, v in row.items()})

import re

# PGSN v0.0.4 以降は `pgsn` パッケージ直下が公開API。
# pgsn.gsn / pgsn.dsl などのサブモジュールは内部実装扱いなので、GSN要素・DSL要素はここから取る。
from pgsn import (
    # GSN要素（v0.0.4で Defeater と Undeveloped が本体に入った）
    goal, evidence, context, strategy, assumption, defeater, undeveloped,
    gsn_class, gsn_tree,
    # DSL要素
    variable,
    string,
    record,
    lambda_abs,
    python_value,
    map_term,
    list_term,
    define_class,
    format_string,
)

# --- GSN拡張ノードのローカル定義 -------------------------------------------
# Justification（正当化）は PGSN 本体に用意されていないため、
# gsn_class を継承してこのモジュール内で定義する（Goal/Strategy の assumptions に載せる）。
justification_class = define_class(inherit=gsn_class, name='Justification')

# Away Goal（GSN v3 モジュール拡張）も PGSN 本体には無いので、ここで定義する。
# 別のモジュールで論じられている主張を参照するだけなので support は持たず、
# 参照先のモジュール名（module）だけを持つ。Goal が置ける場所ならどこにでも置ける。
away_goal_class = define_class(inherit=gsn_class, name='AwayGoal', attributes=["module"])

# 評価しきれなかった項を判別する _to_python_safe() は項の型そのものを見る必要があり、
# 公開APIに対応物が無いため、ここだけは内部モジュール pgsn.pgsn_term を直接参照する。
from pgsn.pgsn_term import (
    String, Integer, Boolean,
    List as PGSNList, Record as PGSNRecord,
    PGSNObject, LambdaInterpreterError
)


def process_description(text: str):
    """
    テキスト内の "{変数名}" を検知し、PGSNの format_string 適用に変換する。
    仕様通り、変数を Record（辞書）にまとめて渡す。
    """
    # {変数名} を抽出
    matches = re.findall(r'\{(.*?)\}', text)

    if not matches:
        return string(text)

    template_str = text

    #変数を Record (辞書) にまとめる
    record_dict = {var_name: variable(var_name) for var_name in matches}
    vars_record = record(record_dict)

    # 3. format_string に「テンプレート」と「Record」を渡す
    term = format_string(string(template_str))(vars_record)

    return term

# --- 1. Frontend JSON -> PGSN Object 変換 ---
def build_gsn_from_json(json_path: str,
                        csv_files: Optional[Dict[str, str]] = None) -> tuple[list[object], dict[str, object]]:
    """
    FlutterのノードJSON（nodes/edges形式）をPGSNオブジェクトツリーに変換する。
    emit() が子ノードを再帰的に構築し、親を持たないGoalをトップゴールとして返す。
    csv_files はエディタから届いたCSVの中身（ファイル名 → 中身）で、FileListノードの読み込みに使う。
    """
    with open(json_path, mode="r", encoding="utf-8") as f:
        data = json.load(f)

    nodes: Dict[str, dict] = {str(n["id"]): n for n in data["nodes"]}
    edges: List[dict] = data["edges"]

    # エッジ情報を「親→子」「子→親」の両方向で引けるように前処理する
    children: Dict[str, List[str]] = {}
    for e in edges:
        f_id, t_id = str(e["from"]), str(e["to"])
        children.setdefault(f_id, []).append(t_id)

    parents: Dict[str, List[str]] = {}
    for e in edges:
        f_id, t_id = str(e["from"]), str(e["to"])
        parents.setdefault(t_id, []).append(f_id)

    node_objs: Dict[str, object] = {}

    def get_desc(n: dict) -> str:
        return (n.get("description") or "").replace('"', '\"')

    def get_support_priority(gsn_type: str) -> int:
        # Goalが複数の子を持つとき、どれを support にするかを型で決める優先順位。
        # Strategyが最優先（0）なのは、サポート構造の主体として戦略を選ぶため。
        priority_map = {
            "Strategy": 0, "Application": 1, "Set": 3, "Map": 4,
            "RecordAccess": 5, "X": 5, "Evidence": 6, "Goal": 7, "AwayGoal": 7, "Undeveloped": 8
        }
        return priority_map.get(gsn_type, 99)

    # 親の横に付く注釈ノード。PGSN v0.0.4 では Context/Assumption は Goal と Strategy の両方が持ち、
    # Defeater（反証）はどのGSNノードにも付けられる（Defeater 自身にも付く＝反証の入れ子）。
    ASSUMPTION_TYPES = ("Assumption", "Justification")

    def split_children(child_ids: List[str]):
        """子を (contexts, assumptions, defeaters, その他のID) に振り分ける。前3つは構築済みTermのリスト。"""
        ctxs, assumps, defs, rest = [], [], [], []
        for cid in child_ids:
            child_typ = nodes[cid]["gsn_type"]
            if child_typ == "Context":
                bucket = ctxs
            elif child_typ in ASSUMPTION_TYPES:
                bucket = assumps
            elif child_typ == "Defeater":
                bucket = defs
            else:
                rest.append(cid)
                continue
            emitted = emit(cid)
            if emitted is not None:
                bucket.append(emitted)
        return ctxs, assumps, defs, rest

    def pick_support(owner_id: str, support_ids: List[str]):
        """
        Goal/Defeater の support を1つ選ぶ。PGSNの support は単一ノードなので、
        複数あれば get_support_priority() の順で先頭を採用する。無ければ PGSN の undeveloped。
        """
        if not support_ids:
            return undeveloped
        support_ids = sorted(support_ids, key=lambda cid: get_support_priority(nodes[cid]["gsn_type"]))
        if len(support_ids) > 1:
            print(f"Warning: ノード {owner_id} の support 候補が複数あるため {support_ids[0]} を採用し、"
                  f"{support_ids[1:]} は無視します。")
        support_id = support_ids[0]
        emitted = emit(support_id)
        if emitted is None:
            return undeveloped
        if nodes[support_id]["gsn_type"] == "Set" and isinstance(emitted, list) and emitted:
            return emitted[0]
        return emitted

    def annotation_kwargs(ctxs, assumps, defs) -> dict:
        # 空のリストは渡さず、PGSN側の既定値（空）に任せる
        kwargs = {}
        if ctxs: kwargs["contexts"] = list_term(tuple(ctxs))
        if assumps: kwargs["assumptions"] = list_term(tuple(assumps))
        if defs: kwargs["defeaters"] = list_term(tuple(defs))
        return kwargs

    def emit(nid: str, depth: int = 0) -> Any:
        # メモ化付き再帰。同一ノードが複数エッジから参照されても1回だけ構築する。
        if nid in node_objs:
            return node_objs[nid]

        if nid not in nodes:
            raise ValueError(f"Node ID {nid} not found in nodes list.")

        node = nodes[nid]
        typ = node["gsn_type"]
        desc = get_desc(node)

        child_ids = children.get(nid, [])
        obj = None

        try:
            # --- pgsn.gsn ---
            if typ == "Context":
                obj = context(description=process_description(desc))

            elif typ == "String":
                # フロントエンドから渡された文字を、純粋なPGSNの文字列項として返す
                desc = node.get("description", "")
                obj = string(desc)

            elif typ == "Evidence":
                # Evidence は Context/Assumption を取らない（GSN規格どおり）。付けられるのは Defeater のみ。
                _, _, defs, rest = split_children(child_ids)
                if rest:
                    print(f"Warning: Evidence {nid} の子 {rest} は Defeater 以外なので無視します。")
                # 元の文字列(desc)を関数に通して、変数が埋め込まれたPGSNのTerm(項)に変換する
                kwargs = {"description": process_description(desc)}
                if defs: kwargs["defeaters"] = list_term(tuple(defs))
                obj = evidence(**kwargs)
            elif typ == "Undeveloped":
                # 未展開。エディタ上で明示的に置かれた場合も PGSN の undeveloped をそのまま使う。
                obj = undeveloped
            elif typ == "X":
                obj = variable(desc)
            elif typ == "Assumption":
                # 前提。Goal/Strategy に付随する注釈として保持される。
                obj = assumption(description=process_description(desc))
            elif typ == "Justification":
                # 正当化。PGSN本体に型が無いためローカル定義クラスで構築する。
                obj = justification_class(description=process_description(desc))
            elif typ == "AwayGoal":
                # 中身は参照先のモジュールで論じられているので、子は Defeater だけを受け付ける
                _, _, defs, rest = split_children(child_ids)
                if rest:
                    print(f"Warning: AwayGoal {nid} の子 {rest} は Defeater 以外なので無視します。")
                kwargs = {"description": process_description(desc),
                          "module": string(node.get("module") or "")}
                if defs: kwargs["defeaters"] = list_term(tuple(defs))
                obj = away_goal_class(**kwargs)
            elif typ == "Defeater":
                # 反証（GSN v3 dialectic extension）。子のうち Defeater は「この反証への反証」として
                # defeaters に、それ以外は反証の主張を支える support（1つ）にする。
                # support が無ければ undeveloped のまま＝未対応(inDoubt)の反証になる。
                _, _, defs, rest = split_children(child_ids)
                kwargs = {"description": process_description(desc),
                          "support": pick_support(nid, rest)}
                if defs: kwargs["defeaters"] = list_term(tuple(defs))
                obj = defeater(**kwargs)
            elif typ == "Strategy":
                ctxs, assumps, defs, rest = split_children(child_ids)
                sub_goals = []
                for cid in rest:
                    emitted_child = emit(cid, depth + 1)

                    # 既にタプル化されている場合（Mapの結果など）の展開
                    if hasattr(emitted_child, 'terms') and isinstance(emitted_child.terms, tuple):
                        for term in emitted_child.terms:
                            sub_goals.append(term.normalize())
                        continue

                    child_typ = nodes[cid]["gsn_type"]
                    if child_typ in ("Goal", "AwayGoal", "Strategy", "Evidence", "Application", "Map", "Set",
                                     "RecordAccess", "X", "Undeveloped"):
                        sub_goals.append(emitted_child)
                    elif emitted_child is not None and hasattr(emitted_child,
                                                               'pgsn_class_name') and emitted_child.pgsn_class_name == 'Goal':
                        sub_goals.append(emitted_child)

                obj = strategy(description=process_description(desc),
                               sub_goals=list_term(tuple(sub_goals)),
                               **annotation_kwargs(ctxs, assumps, defs))

            elif typ == "Goal":
                ctxs, assumps, defs, rest = split_children(child_ids)
                obj = goal(description=process_description(desc),
                           support=pick_support(nid, rest),
                           **annotation_kwargs(ctxs, assumps, defs))

            # --- pgsn.dsl ---
            elif typ == "StringLiteral":
                obj = string(desc)
            elif typ == "RecordLabel":
                if not child_ids: raise ValueError(f"RecordLabelノード {nid} に子ノードが必要です。")
                value_term = emit(child_ids[0], depth + 1)
                obj = (desc, value_term)
            elif typ == "Record":
                record_dict = {}
                for cid in child_ids:
                    if nodes[cid]["gsn_type"] == "FileList":
                        # CSVから直接Recordを構築（ヘッダー=キー、1行目=値）
                        csv_record = load_csv_as_record(nodes[cid]["description"].strip(), csv_files)
                        # csv_recordはPGSN record term。attributes()でdict取得して展開
                        record_dict.update(csv_record.attributes())
                    else:
                        emitted_pair = emit(cid, depth + 1)
                        label_name, value_term = emitted_pair
                        record_dict[label_name] = value_term
                obj = record(record_dict)


            elif typ == "RecordAccess":
                record_term = emit(child_ids[0], depth + 1)
                key = string(desc)
                obj = record_term(key)

            elif typ == "Lambda":
                if not child_ids: raise ValueError(f"Lambdaノード {nid} に本体が必要です。")
                child_objects = [emit(cid, depth + 1) for cid in child_ids]
                if len(child_objects) > 1:
                    body_obj = list_term(tuple(child_objects))
                else:
                    body_obj = child_objects[0]
                arg_term = variable(desc)
                obj = lambda_abs(arg_term, body_obj)

            elif typ == "Application":
                if len(child_ids) != 2:
                    raise ValueError(f"Applicationノード {nid} は厳密に2つの子ノードが必要です。")
                # 関数側（Lambda/Application/X/Map）を自動判定してfunction_idに
                CALLABLE_TYPES = {"Lambda", "Application", "X", "Map"}
                def _callable_priority(cid):
                    return 0 if nodes[cid]["gsn_type"] in CALLABLE_TYPES else 1
                sorted_ids = sorted(child_ids, key=_callable_priority)
                function_id = sorted_ids[0]
                argument_id = sorted_ids[1]
                function_term = emit(function_id, depth + 1)
                argument_term = emit(argument_id, depth + 1)
                obj = function_term(argument_term)


            elif typ == "FileList":
                # descriptionに書かれたCSVファイル名をdata/から読み込む
                obj = load_csv_as_list_term(desc.strip(), csv_files)

            elif typ == "Map":
                if len(child_ids) < 2:
                    raise ValueError(f"Mapノード {desc} には関数と引数が必要です。")
                FUNCTION_TYPES = {"Lambda", "Application", "X"}
                function_ids = [cid for cid in child_ids if nodes[cid]["gsn_type"] in FUNCTION_TYPES]
                data_ids_pool = [cid for cid in child_ids if nodes[cid]["gsn_type"] not in FUNCTION_TYPES]
                if not function_ids:
                    function_ids = [child_ids[0]]
                    data_ids_pool = child_ids[1:]
                function_term = emit(function_ids[0], depth + 1)
                data_argument_ids = data_ids_pool
                all_data_terms = []
                for data_id in data_argument_ids:
                    data_term = emit(data_id, depth + 1)
                    if hasattr(data_term, 'terms') and isinstance(data_term.terms, dict):
                        # Record: フィールド値を展開
                        record_values = list(data_term.terms.values())
                        all_data_terms.extend(record_values)
                    elif hasattr(data_term, 'terms') and isinstance(data_term.terms, tuple):
                        # List（FileListなど）: 要素を個別に展開
                        all_data_terms.extend(data_term.terms)
                    else:
                        all_data_terms.append(data_term)
                final_list_term = list_term(tuple(all_data_terms))
                obj = map_term(function_term, final_list_term)

            node_objs[nid] = obj
            return obj

        except Exception as e:
            print(f"Error processing Node ID {nid} ({typ}): {e}")
            raise e

    def is_top_goal(nid: str) -> bool:
        # ContextノードはGoalの親になれるため、Context以外の親を持たないGoalをトップとする。
        if nodes[nid]["gsn_type"] != "Goal": return False
        non_ctx_parents = [pid for pid in parents.get(nid, []) if nodes[pid]["gsn_type"] != "Context"]
        return len(non_ctx_parents) == 0

    top_goal_ids = [nid for nid in nodes if is_top_goal(nid)]
    tops = [emit(tid, 0) for tid in top_goal_ids]
    return tops, node_objs


# --- 部分評価済みTermの安全な変換 ---
def _to_python_safe(t):
    """
    to_pythonの安全版。App/Absなど評価しきれなかった項は
    Undevelopedプレースホルダーに置き換えて変換を続ける。
    """
    try:
        t = t.fully_eval(steps=1000)
    except LambdaInterpreterError:
        pass  # 部分評価済みのtをそのまま使う

    if isinstance(t, String):
        return t.value
    elif isinstance(t, Integer):
        return t.value
    elif isinstance(t, Boolean):
        return t.value
    elif isinstance(t, PGSNList):
        return [_to_python_safe(item) for item in t.terms]
    elif isinstance(t, PGSNRecord):
        return {k: _to_python_safe(v) for k, v in t.attributes().items()}
    elif isinstance(t, PGSNObject):
        attrs = {k: _to_python_safe(v) for k, v in t.attributes().items()}
        attrs["__" + t.instance.name + "__"] = True
        return attrs
    else:
        # App, Abs など評価しきれなかった項はUndevelopedとして表示
        return {"__Undeveloped__": True, "description": f"<未評価: {type(t).__name__}>"}


def _calc_node_size(description: str) -> tuple[int, int]:
    """
    description の文字数から width / height を推定する。
    日本語混じりを考慮して 1文字 ≈ 9px で計算。
    """
    n = len(description) if description else 0
    CHAR_W  = 9    # 1文字あたりの概算ピクセル幅
    LINE_H  = 22   # 1行あたりのピクセル高さ
    PAD_X   = 20   # 左右パディング合計
    PAD_Y   = 20   # 上下パディング合計
    MIN_W, MAX_W = 100, 340
    MIN_H        = 60

    width = max(MIN_W, min(MAX_W, n * CHAR_W + PAD_X))
    chars_per_line = max(1, (width - PAD_X) // CHAR_W)
    lines  = max(1, math.ceil(n / chars_per_line))
    height = max(MIN_H, lines * LINE_H + PAD_Y)
    return int(width), int(height)


# --- 2. Evaluated Object -> Flat Graph JSON 変換 ---
def export_gsn_json(evaluated_term, safe=False):
    """
    fully_eval()の結果(PGSNObject)を、フロントエンド描画用のノード・エッジリスト形式に変換する。
    RecordなどのGSN型でない要素はノード生成をスキップし（Pass-through）、
    その子要素を親の直下に接続することで、図のネスト深度を浅く保つ。
    safe=True のとき、評価しきれなかった項も Undeveloped プレースホルダーとして出力する。
    """

    # PGSNObject -> Python Dict/List に変換
    # safe=Trueのとき: 評価しきれなかった項もプレースホルダーで変換する
    py_data = _to_python_safe(evaluated_term) if safe else python_value(evaluated_term)

    nodes = []
    edges = []
    level_map = {}

    # PGSNの属性キー（これらの中身を再帰探索する）
    FLATTEN_KEYS = ["support", "contexts", "assumptions", "defeaters", "sub_goals"]

    def _traverse(data, parent_id=None, level=0):
        # リストの処理（リスト自体はノードにせず、中身を展開）
        if isinstance(data, list) or isinstance(data, tuple):
            for item in data:
                _traverse(item, parent_id, level)
            return

        # --- 1. ノードとして描画するかどうかの判定 ---
        should_draw = False
        gsn_type = "Unknown"
        description = ""

        # 辞書（PGSNオブジェクトの成れの果て）の場合
        if isinstance(data, dict):
            # GSN型キーの特定 (例: '__Goal__', '__Strategy__' など)
            type_key = next((k for k in data if k.startswith('__') and k.endswith('__')), None)

            if type_key:
                # GSN型が見つかった -> 描画する
                should_draw = True
                gsn_type = type_key.strip('_')  # "__Goal__" -> "Goal"
                description = data.get("description", str(data.get("value", "")))

                # 未展開(Undeveloped)はGSN規格では独立ノードではなく、親ノード下辺の小さな菱形の印。
                # 親に "undeveloped": True を付けるだけにしてノードは作らない。
                # （_to_python_safe が評価しきれなかった項に使う説明付きのUndevelopedはノードとして残す）
                if gsn_type == "Undeveloped" and not description and parent_id is not None:
                    nodes[parent_id]["undeveloped"] = True
                    return
            else:
                # GSN型がない辞書（Recordなど） -> 描画しない
                should_draw = False

        # 辞書以外（文字列や数値などのプリミティブな値）
        elif isinstance(data, (str, int, float, bool)):
            # 値ノードとして描画する (必要に応じてFalseにしてもよい)
            should_draw = True
            gsn_type = "Value"
            description = str(data)

        else:
            # Noneなどは無視
            return

        # --- 2. ノードの登録処理 ---
        current_node_id = None  # 子供に渡す親ID

        if should_draw:
            # 新しいノードを作成
            node_id = len(nodes)  # シンプルな数値ID

            display_desc = description
            node_w, node_h = _calc_node_size(display_desc)

            nodes.append({
                "id": node_id,
                "gsn_type": gsn_type,
                "description": display_desc,
                "position_x": 0.0,  # 後で計算
                "position_y": 0.0,
                "width": node_w,
                "height": node_h
            })
            # Away Goal は参照先のモジュール名をエディタに渡す（帯に表示する）
            if isinstance(data, dict) and gsn_type == "AwayGoal":
                nodes[-1]["module"] = str(data.get("module") or "")

            # 親がいればエッジを結ぶ
            if parent_id is not None:
                edges.append({"from": parent_id, "to": node_id})

            # レベル管理（レイアウト用）
            if level not in level_map: level_map[level] = []
            level_map[level].append(node_id)

            # 子供には「自分」を親として渡す
            current_node_id = node_id
            next_level = level + 1
        else:
            # ★Pass-through: ノードを作らず、子供には「今の親」をそのまま渡す
            current_node_id = parent_id
            next_level = level  # 階層も深くしない

        # --- 3. 子要素の再帰探索 ---
        if isinstance(data, dict):
            for key, value in data.items():
                # メタデータや値そのものは探索しない
                if key.startswith('__') or key in ["description", "value", "module"]:
                    continue

                # 既知の属性キー、またはそれ以外のキーも値が構造体なら探索
                _traverse(value, current_node_id, next_level)

    # ルートから探索開始
    _traverse(py_data)

    # --- 4. ツリーレイアウト計算 (サブツリー幅基準・親子中央揃え) ---
    x_gap = 20.0
    y_spacing = 160.0
    margin = 50.0

    # エッジから子リストを構築
    children_map: dict[int, list[int]] = {n["id"]: [] for n in nodes}
    for e in edges:
        children_map[e["from"]].append(e["to"])

    # ルートノード（親を持たないもの）を特定
    has_parent = {e["to"] for e in edges}
    roots = [n["id"] for n in nodes if n["id"] not in has_parent]

    ctx_side_gap = 40.0
    UNDEVELOPED_MARKER_H = 14.0  # Flutter側 _undevelopedMarkerSize の高さと揃える  # Goalとcontextノードの間の横方向の隙間

    # ★Flutterエディタ(_autoLayout)とレイアウトを揃えるための「横付けノード」定義。
    # Context/Assumption/Justification/Defeater は親の左右に振り分ける（下方向の主フローに載せない）。
    # Defeater だけは横に付けた上で、自身の子（反論チェーン）を真下に展開する（EXPANDABLE）。
    SIDE_TYPES = {"Context", "Assumption", "Justification", "Defeater"}
    EXPANDABLE_SIDE_TYPES = {"Defeater"}

    def _ctx_split(nid: int):
        """横付けノード（SIDE_TYPES）の子を左右に分割して返す (left_list, right_list)"""
        ctx = [c for c in children_map[nid] if nodes[c]["gsn_type"] in SIDE_TYPES]
        n_left = len(ctx) // 2  # 奇数なら右が1つ多い
        return ctx[:n_left], ctx[n_left:]

    def _side_width(cid: int) -> float:
        # 横付けノードが横方向に占める幅。Defeaterは自身にもDefeater（反証への反証）が付き得るので、
        # その分を外側へ再帰的に足す（PGSN v0.0.4 で全GSNノードが defeaters を持つようになったため）。
        w = nodes[cid]["width"]
        if nodes[cid]["gsn_type"] in EXPANDABLE_SIDE_TYPES:
            nested = [c for c in children_map[cid] if nodes[c]["gsn_type"] in SIDE_TYPES]
            if nested:
                w += ctx_side_gap + max(_side_width(c) for c in nested)
        return w

    def _ctx_extra_left(nid: int) -> float:
        left_ctxs, _ = _ctx_split(nid)
        if not left_ctxs:
            return 0.0
        return max(_side_width(c) for c in left_ctxs) + ctx_side_gap

    def _ctx_extra_right(nid: int) -> float:
        _, right_ctxs = _ctx_split(nid)
        if not right_ctxs:
            return 0.0
        return max(_side_width(c) for c in right_ctxs) + ctx_side_gap

    # ★Flutterエディタ(_autoLayout)の非対称レイアウトを移植。
    # 中心からの張り出しを左右別々(base_half_left/right)に持つことで、片側にだけ
    # 横付けノード（Defeaterとその反論チェーン）がある場合のはみ出し衝突を防ぐ。
    base_half_left: dict[int, float] = {}
    base_half_right: dict[int, float] = {}

    def _subtree_width(nid: int) -> float:
        # 横付け要素も含むサブツリー全体の幅。兄弟を横並びする間隔計算に使う。
        return _ctx_extra_left(nid) + base_half_left[nid] + base_half_right[nid] + _ctx_extra_right(nid)

    def _compute_extents(nid: int):
        # 中心からの左右の張り出し(base_half_left/right)を再帰的に求める。
        if nid in base_half_left:
            return
        non_ctx = [c for c in children_map[nid] if nodes[c]["gsn_type"] not in SIDE_TYPES]
        half_w = nodes[nid]["width"] / 2
        if not non_ctx:
            hl = hr = half_w
        elif len(non_ctx) == 1:
            # 子1つ: 子の本体中心を親中心に合わせるため、子の張り出しを引き継ぐ（左右非対称になりうる）
            c = non_ctx[0]
            _compute_extents(c)
            l = base_half_left[c] + _ctx_extra_left(c)
            r = base_half_right[c] + _ctx_extra_right(c)
            hl = max(half_w, l)
            hr = max(half_w, r)
        else:
            for c in non_ctx:
                _compute_extents(c)
            total = sum(_subtree_width(c) for c in non_ctx) + x_gap * (len(non_ctx) - 1)
            hl = hr = max(half_w, total / 2)
        base_half_left[nid] = hl
        base_half_right[nid] = hr

    for n in nodes:
        _compute_extents(n["id"])

    placed: set = set()

    def _place_children_below(parent_nid: int, center_x: float, child_depth: int):
        # center_x の真下に、通常の子ノード群を横並びの中央揃えで展開する。
        children = [c for c in children_map[parent_nid] if nodes[c]["gsn_type"] not in SIDE_TYPES]
        if not children:
            return
        if len(children) == 1:
            cid = children[0]
            if cid not in placed:
                placed.add(cid)
                _place(cid, center_x, child_depth)
            return
        total = sum(_subtree_width(c) for c in children) + x_gap * (len(children) - 1)
        cursor = center_x - total / 2
        for cid in children:
            if cid not in placed:
                placed.add(cid)
                # cursorはサブツリー左端。左横付け分と左張り出し分を進めた位置が本体中心。
                _place(cid, cursor + _ctx_extra_left(cid) + base_half_left[cid], child_depth)
            cursor += _subtree_width(cid) + x_gap

    def _place(nid: int, base_center: float, depth: int):
        w = nodes[nid]["width"]
        nodes[nid]["position_x"] = base_center - w / 2
        nodes[nid]["position_y"] = margin + depth * y_spacing
        node_y = nodes[nid]["position_y"]

        # 通常の子を真下に展開
        _place_children_below(nid, base_center, depth + 1)

        # 横付けノードは「本体+子孫が実際に占める領域」の外側へ置く（左右非対称の張り出しを使う）
        content_left_edge = base_center - base_half_left[nid]
        content_right_edge = base_center + base_half_right[nid]
        left_ctxs, right_ctxs = _ctx_split(nid)

        _place_side_nodes(left_ctxs, content_left_edge, node_y, depth, to_left=True)
        _place_side_nodes(right_ctxs, content_right_edge, node_y, depth, to_left=False)

    def _place_side_nodes(side_ids: list, edge_x: float, top_y: float, depth: int, to_left: bool):
        # edge_x の外側（to_left なら左、そうでなければ右）へ横付けノードを縦に積む。
        y = top_y
        for cid in side_ids:
            placed.add(cid)
            cw = nodes[cid]["width"]
            ch = nodes[cid]["height"]
            nodes[cid]["position_x"] = edge_x - ctx_side_gap - cw if to_left else edge_x + ctx_side_gap
            nodes[cid]["position_y"] = y
            # 下辺に未展開の菱形が付くノードは、その分だけ次の横付けノードを下げる
            y += ch + 10 + (UNDEVELOPED_MARKER_H if nodes[cid].get("undeveloped") else 0)
            # Defeater等は横に付けた上で、自身の子（反論チェーン）を真下に展開する
            if nodes[cid]["gsn_type"] in EXPANDABLE_SIDE_TYPES:
                _place_children_below(cid, nodes[cid]["position_x"] + cw / 2, depth + 1)
                # 反証への反証（入れ子のDefeater）は、同じ向きのさらに外側へ付ける
                nested = [c for c in children_map[cid] if nodes[c]["gsn_type"] in SIDE_TYPES]
                outer_edge = nodes[cid]["position_x"] if to_left else nodes[cid]["position_x"] + cw
                _place_side_nodes(nested, outer_edge, nodes[cid]["position_y"], depth, to_left)

    # Goalルートを先に配置（PGSN由来のルートより優先）
    sorted_roots = [r for r in roots if nodes[r]["gsn_type"] == "Goal"] + \
                   [r for r in roots if nodes[r]["gsn_type"] != "Goal"]

    cursor = margin
    for rid in sorted_roots:
        if rid not in placed:
            placed.add(rid)
            _place(rid, cursor + _ctx_extra_left(rid) + base_half_left[rid], 0)
        cursor += _subtree_width(rid) + x_gap * 2

    # 負座標補正
    if nodes:
        min_x = min(n["position_x"] for n in nodes)
        if min_x < margin:
            shift = margin - min_x
            for n in nodes:
                n["position_x"] += shift

    return {"nodes": nodes, "edges": edges}


def main():
    import argparse

    json_path = "gsn_diagram.json"
    if len(sys.argv) > 1:
        json_path = sys.argv[1]

    try:
        # GSNノードの構築
        tops, _ = build_gsn_from_json(json_path)

        if not tops:
            print(json.dumps({"error": "No top-level Goal found."}))
            return

        # ここでは最後のTop Goalのみを出力対象とする（複数はリストにするなどの対応が必要）
        target_top = tops[-1]

        # 評価実行 (ステップ数は必要に応じて調整)
        evaluation_result = target_top.fully_eval(steps=10000)

        print(evaluation_result)

        gsn_tree(evaluation_result).show()

        # グラフデータへの変換
        graph_json = export_gsn_json(evaluation_result)

        # 最終結果をJSONとして標準出力へ (これをAPIレスポンスとして使う)
        print(json.dumps(graph_json, indent=2, ensure_ascii=False))

    except Exception as e:
        # エラー時もJSON形式で返すとフロントエンドが扱いやすい
        error_res = {"error": str(e), "trace": traceback.format_exc()}
        print(json.dumps(error_res, indent=2))


if __name__ == "__main__":
    main()